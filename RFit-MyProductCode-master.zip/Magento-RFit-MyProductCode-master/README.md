# Magento-RFit-MyProductCode
Magento example on creating and customizing product attributes

Magento uses EAV (Entity Attribute Value) to store value/attribute of products, customers, etc. Creating an attribute for products in Magento is very easy. You can manually add it in admin page through ‘Catalog’ -> ‘Attributes’ -> ‘Manage Attributes’ -> ‘New Attribute’, or using extension as described in this article.
Goal

Add a ‘My Product Code’ field to product, which can be edit/save in admin product page, and its value can be read and shown in frontpage or admin

http://richardfu.net/magento-create-an-attribute-for-products-using-addattribute-in-extension/
