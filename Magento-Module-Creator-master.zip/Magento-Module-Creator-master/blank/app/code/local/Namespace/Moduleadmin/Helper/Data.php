<?php

class <Namespace>_<Moduleadmin>_Helper_Data extends Mage_Core_Helper_Abstract
{

}