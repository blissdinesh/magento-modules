		<span id="version">v.0.0.9.2 | <a href="http://www.magentocommerce.com/wiki/custom_module_with_custom_database_table" target="_blank">check for updates &amp; help</a></span>		
	</div>
</body>
</html>