<?php

class Dhmedia_Devel_Block_Page_Html extends Mage_Page_Block_Html
{
	public function getShowTemplateHints()
	{
		return false;
	}
}