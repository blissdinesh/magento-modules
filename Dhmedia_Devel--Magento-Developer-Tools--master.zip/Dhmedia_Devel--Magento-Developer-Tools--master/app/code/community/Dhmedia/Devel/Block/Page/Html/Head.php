<?php

class Dhmedia_Devel_Block_Page_Html_Head extends Mage_Page_Block_Html_Head
{
	public function getShowTemplateHints()
	{
		return false;
	}
}