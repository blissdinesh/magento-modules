<?php

/**
 * @deprecated
 */
abstract class Dhmedia_Devel_Model_Writer_Abstract
{
	
}