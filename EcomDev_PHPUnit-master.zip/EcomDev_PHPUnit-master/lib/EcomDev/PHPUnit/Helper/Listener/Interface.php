<?php


/**
 * @deprecated after 0.4.0
 */
interface EcomDev_PHPUnit_Helper_Listener_Interface 
    extends EcomDev_PHPUnit_Helper_ListenerInterface
{
    
}
