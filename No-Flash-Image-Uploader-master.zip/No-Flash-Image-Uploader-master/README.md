No Flash Image Uploader
=======================

This Magento module allows the upload of product images and WYSIWYG media without having the Flash player installed. It has been removed from Magento Connect, so I retrieved it from a customer project and put it up on Github.

Supported versions
------------

Tested with:
* Magento Community Edition 1.7
* Magento Enterprise Edition 1.14.2.0

The extension is automatically enabled, i.e. there is no backend setting or configuration available.

Installation
------------

Just upload the app and js folders to your Magento installation or install via composer if you're a developer.
