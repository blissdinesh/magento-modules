# Magento Tools [![Package Atom](https://img.shields.io/badge/Package-Atom-blue.svg)](https://atom.io/packages/magento-tools)  [![Version 0.0.2](https://img.shields.io/badge/Release-0.0.2-green.svg)](https://github.com/rafaelstz/atom-magento-tools/releases)


Ideal for developing Magento themes, get hints of the main functions, classes and methods. This plugin will greatly facilitate the development, mainly on the frontend. He suggests methods, built-in functions and classes Magento quickly and easily, it besides being open has a very simple way of contribution to customize your way.


##Contribute and Suggestions

If you have something to improve these plugin, please create a [issue](https://github.com/rafaelstz/atom-magento-tools/issues).


![Suggestions](https://f.cloud.github.com/assets/69169/2290250/c35d867a-a017-11e3-86be-cd7c5bf3ff9b.gif)

## LICENSE
(c) MIT 2015 - 2016, [Rafael Corrêa Gomes](https://github.com/rafaelstz)
