<?php

class Mango_Ajaxlist_Helper_Data extends Mage_Core_Helper_Abstract{

    const  _AJAX_PARAMETER = 'ajaxlist';

    public function getAjaxParameter(){
        return $this::_AJAX_PARAMETER;
    }

    public function removeAjaxParameters( &$_params ){
        $_params[ $this::_AJAX_PARAMETER ] = null;
        return $_params;
    }

    
     /**
     * Get all fiterable attributes of current category
     *
     * @return array
     */
    public function getFilterableAttributes( $_layer_block )
    {
        $attributes = $_layer_block->getData('_filterable_attributes');
        if (is_null($attributes)) {
            $attributes = $_layer_block->getLayer()->getFilterableAttributes();
            //$_layer_block->setData('_filterable_attributes', $attributes);
        }

        return $attributes;
    }

}