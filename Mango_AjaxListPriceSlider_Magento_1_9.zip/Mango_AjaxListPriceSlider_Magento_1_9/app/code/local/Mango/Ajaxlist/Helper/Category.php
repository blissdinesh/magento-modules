<?php

class Mango_Ajaxlist_Helper_Category extends Mage_Core_Helper_Abstract {

    protected $_active_filter = false;
    
    protected $_category_tree_depth = false;
    
    protected function _checkCategoryTreeDeph($level) {
        
        if($this->_category_tree_depth===false){
            $this->_category_tree_depth = (int)Mage::getStoreConfig("ajaxlist/ajaxlist/category_tree_depth");
        }
        if($this->_category_tree_depth > 0){
            if($level >= $this->_category_tree_depth) return false;
        }
        
        return true;
    }
    
    
    /**
     * Template for filter items block
     *
     * @see Mage_Catalog_Block_Layer_Filter
     */
    /* first: get category tree based on current category... */
    function renderCategoryMenuItemHtml($category, $_layer_items, $level = 0, $isLast = false, $isFirst = false, $include_parent = false, $return_child_ids = false) {
        
        /*if(!$this->_checkCategoryTreeDeph($level)){
            if($return_child_ids){
                return array('', array());
            }else{
                return '';
            }
        }*/
        
        if (!$category->getIsActive()) {
            return '';
        }
        $html = array();
        /* find children only if the category depth is valid... */
        $children =  ($this->_checkCategoryTreeDeph($level))? $this->getChildrenCategories($category) : array();
        // select active children
        $activeChildren = array();
        foreach ($children as $child) {
            if ($child->getIsActive()) {
                $activeChildren[] = $child;
            }
        }
        $activeChildrenCount = count($activeChildren);
        $hasActiveChildren = ($activeChildrenCount > 0);
        // prepare list item html classes
        $classes = array();
        $classes[] = 'level' . $level;

        $linkClass = '';
        $selectAllClass = array();

        if ($isFirst) {
            $classes[] = 'first';
        }
        if ($isLast) {
            $classes[] = 'last';
        }
        if ($hasActiveChildren) {
            $classes[] = 'parent';
            $linkClass = "category-expand link-expand-collapse";
        } else {
            $classes[] = 'child';
        }
        if ($this->isItemActive($category->getId())) {
            $classes[] = 'active-filter-option';
        }
        // prepare list item attributes
        $attributes = array();
        if (count($classes) > 0) {
            $attributes['class'] = implode(' ', $classes);
        }

        if ($include_parent) {

            // assemble list item with attributes
            $htmlLi = '<li';
            foreach ($attributes as $attrName => $attrValue) {
                $htmlLi .= ' ' . $attrName . '="' . str_replace('"', '\"', $attrValue) . '"';
            }
            $htmlLi .= '>';
            $html[] = $htmlLi;
            $html[] = '<a href="' . $this->getUrl(array($category->getId()), $category->getParentCategory()->getId()) . '" data-attribute-value="' . $category->getId() . '" class="' . $linkClass . '">';
            $html[] = Mage::helper('core')->escapeHtml($category->getName());

            if ($_layer_items && isset($_layer_items[$category->getId()])) {
                $_count = $_layer_items[$category->getId()]->getCount();
            } else {
                // $_count = $category->getProductCount();
                $_count = Mage::getModel('catalog/layer')->setCurrentCategory($category)->getProductCollection()->getSize();
            }

            //
            //}
            $html[] = '<span class="item-count">(' . (int) $_count . ')</span>';
            $html[] = '</a>';
        }


        // render children
        $htmlChildren = '';
        $j = 0;
        $_children_ids = array($category->getId());
        foreach ($activeChildren as $child) {
            $_children_ids[] = $child->getId();
            $processChildren = $this->renderCategoryMenuItemHtml(
                    $child, $_layer_items, ($level + 1), ($j == $activeChildrenCount - 1), ($j == 0), true, true );
            $j++;
            $htmlChildren .= $processChildren[0]; /* index 0 : html , index 1: array of children id's */
            $_children_ids = array_merge($_children_ids, $processChildren[1]);
        }
        if (!empty($htmlChildren)) {

            $_children_ids  = array_unique($_children_ids);
            if ($hasActiveChildren && $include_parent) {
                if( $this->isParentItemActive($_children_ids))$selectAllClass[] = 'all-selected';
                $html[] = '<a href="' . $this->getUrl($_children_ids , $category->getId()) . '" data-attribute-value="' . join(",", $_children_ids) . '" class="select-all-subcategories-link ' . implode(" ", $selectAllClass) . '">'
                        . '<span class="select-all-subcategories-text">' . Mage::helper('core')->escapeHtml($category->getName()) . '</span>'
                        . '</a>';
            }

            if ($include_parent)
                $html[] = '<ul class="level' . $level . '">';
            $html[] = $htmlChildren;
            if ($include_parent)
                $html[] = '</ul>';
        }
        if ($include_parent)
            $html[] = '</li>';

        $html = implode("\n", $html);
        if($return_child_ids){
            return array($html , $_children_ids);
        }
        /* default return... */
        return $html;
    }

    function getUrl($_values, $_parent_id = null) {
        $_query = Mage::app()->getRequest()->getQuery();
        $_url_param = Mage::app()->getRequest()->getParam('cat');
        $_filter = $this->getActiveFilters();
        /*if (preg_match('/^[0-9,]+$/', $_url_param)) {
            $_filter = explode(',', $_url_param);
        } elseif ((int) $_url_param > 0) {
            $_filter[] = $_url_param;
        }*/

        if (count($_values) === 1) { /* link to remove current filter only and its parent */
            foreach ($_values as $_value) {
                if (in_array($_value, $_filter)) {/* item is selected, then remove from array */
                    array_splice($_filter, array_search($_value, $_filter), 1);
                    if(in_array($_parent_id, $_filter))/* also remove its parent, to be selected, all child items should be selected */
                        array_splice($_filter, array_search($_parent_id, $_filter), 1);
                } else {
                    $_filter[] = $_value;
                }
            }
        } else {
            /* item is a parent link and parameter should include its children
             * if all items are selected, then create link to remove all values (uncheck) , 
             * otherwise, create link to select all values ( check all )  */

            # checking if all items are selected
            $_all_items_selected = true;
            foreach ($_values as $_value) {
                if (!in_array($_value, $_filter)) {
                    $_all_items_selected = false;
                    break;
                }
            }

            if ($_all_items_selected) {
                $_filter_2 = array(); /* the url parameter includes the parent category id*/
                foreach ($_filter as $_v) {
                    /* skip filter items */
                    if(!in_array($_v, $_values) && $_v!=$_parent_id )
                            $_filter_2[] = $_v;
                }
                
                $_filter = $_filter_2;
            } else {
                /* remove parent id from filters array */
                if($_parent_id  && array_search($_parent_id, $_filter) !== false){
                    array_splice($_filter, array_search($_parent_id, $_filter), 1);
                }
                /*  */
                foreach ($_values as $_value) {
                    if (!in_array($_value, $_filter)) {
                        $_filter[] = $_value;
                    }
                }
            }
        }
        $_filter = array_unique($_filter);
        $_filter = join(",", $_filter);
        if(!trim($_filter)) $_filter = null;
        $_query['cat'] = $_filter;

        Mage::helper("ajaxlist")->removeAjaxParameters($_query);
        $_query[Mage::getBlockSingleton('page/html_pager')->getPageVarName()] = null;

        if (Mage::app()->getRequest()->getControllerName() == "result" && Mage::app()->getRequest()->getModuleName() == "catalogsearch") {
            $_url = Mage::getUrl('*/*', array('_current' => true, '_use_rewrite' => true, '_query' => $_query));
        } else {
            $_url = Mage::getUrl('*/*/*', array('_current' => true, '_use_rewrite' => true, '_query' => $_query));
        }
        return $_url; // Mage::helper('core')->escapeUrl($_url);
    }

    function isItemActive($_value) {
        
        $_filter = $this->getActiveFilters();
        
        if (in_array($_value, $_filter)) {
            return true;
        } else {
            return false;
        }
    }
    
    public function getActiveFilters(){
        if($this->_active_filter== false){
            $_url_param = Mage::app()->getRequest()->getParam('cat');
            $_filter = array();
            if (preg_match('/^[0-9,]+$/', $_url_param)) {
                $_filter = explode(',', $_url_param);
            } elseif ((int) $_url_param > 0) {
                $_filter[] = $_url_param;
            }
            $this->_active_filter = $_filter;
        }
        return $this->_active_filter;
    }
    
    
    function isParentItemActive($_values ) {
        $_filter = $this->getActiveFilters();
        foreach($_values as $_value ){
            if (!in_array($_value, $_filter)) {
                return false;
            }
        }
        return true;
    }
    
    
    public function getChildrenCategories($_category) {
        $_subcategories = $_category->getCollection()
                ->addAttributeToSelect('url_key')
                ->addAttributeToSelect('name')
                ->addAttributeToSelect('all_children')
                ->addAttributeToSelect('is_anchor')
                ->setOrder('position', Varien_Db_Select::SQL_ASC)
                ->joinUrlRewrite()
                ->addAttributeToFilter('is_active', 1)
                ->addIdFilter($_category->getChildren());

        if (!Mage::getStoreConfig("ajaxlist/ajaxlist/show_hidden_categories")) {
            $_subcategories->addAttributeToFilter('include_in_menu', 1);
        }
        $_subcategories->load();

        return $_subcategories;
    }

}
