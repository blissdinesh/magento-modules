<?php
        /**
        * Ak  Customattribute
        * This module is adding custom attribute in customer section and displaying in customer grid .
        * @category    Ak
        * @package     Ak_Customattribute
        */

        /**
        * Ak  Customattribute
        *
        * @category   Ak
        * @package    Ak_Customattribute
        * @author     Adesh Kumar <adeshsuryan2005@gmail.com>
        */
 
class Ak_Customattribute_Helper_Data extends Mage_Core_Helper_Abstract
{

}