<?php
class NextBits_AjaxSuite_Block_AjaxSuite extends Mage_Core_Block_Template
{
	public function _prepareLayout()
    {
		return parent::_prepareLayout();
    }
    
     public function getAjaxSuite()     
     { 
        if (!$this->hasData('ajaxsuite')) {
            $this->setData('ajaxsuite', Mage::registry('ajaxsuite'));
        }
        return $this->getData('ajaxsuite');
        
    }
}