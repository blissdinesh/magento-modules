<?php
class NextBits_AjaxSuite_Block_Config extends Mage_Core_Block_Abstract {

	public function _toHtml() {
		$content = "";
		
			$configs = array(
				'selector'	=> array(
					'paginator'			=> 'ajaxsuite/selector/paginator',
					'limiter'			=> 'ajaxsuite/selector/limiter',
					'mode'				=> 'ajaxsuite/selector/mode',
					'sortby'			=> 'ajaxsuite/selector/sortby',
					'sortdir'			=> 'ajaxsuite/selector/sortdir',
					'navfilter'			=> 'ajaxsuite/selector/navfilter',
					'navclear'			=> 'ajaxsuite/selector/navclear',
					'navremove'			=> 'ajaxsuite/selector/navremove'
				),
				'content'	=> array(
					'name'				=> 'ajaxsuite/blockcontent/name',
					'selector'			=> 'ajaxsuite/blockcontent/selector',
					'replace'			=> 'ajaxsuite/blockcontent/replace'
				),
				'layer'		=> array(
					'name'				=> 'ajaxsuite/blocklayer/name',
					'selector'			=> 'ajaxsuite/blocklayer/selector',
					'replace'			=> 'ajaxsuite/blocklayer/replace'
				)
			);
			
			$newConfig = array();
			foreach ($configs as $confKey => $_data) {
				foreach ($_data as $dataKey => $dataVal) {
					$tempVal = Mage::getStoreConfig($dataVal);
					if (!empty($tempVal)) {
						if (!isset($newConfig[$confKey]))
							$newConfig[$confKey] = array();
						$newConfig[$confKey][$dataKey] = $tempVal;
					}
				}
			}
			
			if (count($newConfig)) {
				foreach ($newConfig as $key => $data) {
					switch ($key) {
						case 'selector' :
							foreach ($data as $_key => $_val) {
								$content.= "NB.catalogajax.config.".$_key."='".$_val."';\n";
							}
							break;
						case 'content' :
							foreach ($data as $_key => $_val) {
								$content.= "NB.catalogajax.config.blocks.content.".$_key."='".$_val."';\n";
							}
							break;
						case 'layer' :
							foreach ($data as $_key => $_val) {
								$content.= "NB.catalogajax.config.blocks.layer.".$_key."='".$_val."';\n";
							}
							break;
						default:
							continue;
					} 
				}
			}
			if (Mage::app()->getFrontController()->getAction()->getFullActionName() == 'catalogsearch_result_index') {
				$searchBlockName = Mage::getStoreConfig('ajaxsuite/blocksearchlayer/name');
				$content.= 'NB.catalogajax.config.blocks.layer.name = \''.(($searchBlockName)?$searchBlockName:'catalogsearch.leftnav').'\';'."\n";
				$temp = Mage::getStoreConfig('ajaxsuite/blocksearchlayer/selector');
				if ($temp) {
					$content.= 'NB.catalogajax.config.blocks.layer.selector = \''.$temp.'\''."\n";
				}
				$temp = Mage::getStoreConfig('ajaxsuite/blocksearchlayer/replace');
				if ($temp) {
					$content.= 'NB.catalogajax.config.blocks.layer.replace = \''.$temp.'\''."\n";
				}
			}
			if ($content) {
				$content = "<script type=\"text/javascript\">\n".$content."\n</script>\n";
			}
		return $content;
	}
		
}
?>